import React from "react";

import { Contact as ContactComponent } from "../components/ContactSection/Contact";

const Contact = () => {
  return <ContactComponent />;
};

export default Contact;
