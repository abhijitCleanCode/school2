import React from "react";
import Gallary from "../components/GallarySection/Gallary";

const Gallery = () => {
  return <Gallary />;
};

export default Gallery;
